def count_alex_occurrences():
    s = input("Enter a string: ")
    print(s.count("Alex"))

count_alex_occurrences()
